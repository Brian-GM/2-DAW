#!/usr/bin/env python
import json

print "Content-Type: text/html"
print ""

datos = {"mensaje": "Datos creados en el servidor"}
respuesta = json.dumps(datos)

print(respuesta)