<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $datos = json_decode(file_get_contents("php://input"), true);

    echo "Este es el Nombre: " . $datos['nombre'] . ", la Edad: " . $datos['edad'] . ", y la Ciudad: " . $datos['ciudad'];

} else {

    echo "Error";
}

?>