<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $mensaje = $_POST["mensaje"];

    echo "Mensaje recibido en el servidor - Mensaje: " . $mensaje;

} else {

    echo "Error: Solo se permiten solicitudes POST";

}
?>