#!/usr/bin/env python
import sys
import json

print "Content-Type: text/html"
print ""

data = json.loads(sys.stdin.read())
print("Datos recibidos en el servidor desde el cliente {nombre} {edad} {ciudad}".format(nombre=data['nombre'], edad=data['edad'], ciudad=data['ciudad']))